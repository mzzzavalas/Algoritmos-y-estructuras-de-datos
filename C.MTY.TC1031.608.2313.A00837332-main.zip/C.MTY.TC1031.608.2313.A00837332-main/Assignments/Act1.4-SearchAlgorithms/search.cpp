#include <iostream>
using namespace std;


void secuencial(int miVector[]){
    
}


int main(){

int miVector[5] = {8, 12, 23, 32, 40};
int l=0;
//int r=miVector.size-1;

/*/for(int i=0;i<5;i++){
    if(miVector[i]==x){
        cout<<"Se encontro en la posicion: "<<i<<endl;
    }
}


while(x!=y){
    mid=left+

}

/*/
return 0;
}
